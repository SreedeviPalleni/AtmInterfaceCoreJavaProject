package newatminterface;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TransactionClass {
static Connection conn=null;
static Statement st=null;
static ResultSet rs=null;
 static int c;
 static int pno;
static float withdraw=0,deposit=0;
 static String cname;
static String transtype;
 static float availablebal=1000;
 static BufferedReader br;
public static void addRecords() throws IOException {
	conn=JdbcConnectivity.getConnection();
	try 
	{
		
		st=conn.createStatement();
		String sel="select count(*) cnt from transactionhistory";
		rs=st.executeQuery(sel);
		if(rs.next()) {
		c = rs.getInt("cnt");
		}
		if(c==0) {
		pno=54321;
		}
		else if(c!=0) {
			String sel1="select max(pno) no from transactionhistory";
			rs=st.executeQuery(sel1);
			if(rs.next()) {
				pno=rs.getInt("no")+1;
				}
			}
	
		br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter your customer name");
		cname=br.readLine();
		/*System.out.println("enter minimum available bal");
		
		availablebal=Float.parseFloat(br.readLine());*/
		
		
		
		String ins= "insert into transactionhistory values("+pno+",'"+cname+"','"+transtype+"',"+withdraw+" ,"+deposit+","+availablebal+")";
		int i=st.executeUpdate(ins);
		if(i>0) {
			System.out.println("new pin generated");
			System.out.println(availablebal);
			}
		else {
			System.out.println("not inserted");
		}
	}catch(SQLException e) {
		e.printStackTrace();
	}
		
	
}
public static void depositAmount()throws IOException {
	transtype="credit";
	conn=JdbcConnectivity.getConnection();
	try {
		st=conn.createStatement();
		
		br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the pin num that you want to deposit");
		int pno=Integer.parseInt(br.readLine());
		String s="select pno from transactionhistory where pno="+pno;
		ResultSet rs=st.executeQuery(s);
		
		
		System.out.println("enter amount that you want to deposit");
		Float amt=Float.parseFloat(br.readLine());
		System.out.println(availablebal);
		
		if(rs.next()) {
			if(amt>0) {
				
				 availablebal=availablebal+amt;
				System.out.println(availablebal);
			String up="update transactionhistory set deposit="+amt+",availablebal="+availablebal+",transtype='"+transtype+"' where pno="+pno;
			int i=st.executeUpdate(up);
			if(i>=0) {
				System.out.println("updated");
				
				}
			else {
				System.out.println("not updated");
			}
			
			
		}
		
		}
		
		 }catch(Exception e) {
			 e.printStackTrace();
		 }

}
public static void withdrawAmount() throws IOException {
	 transtype="debit";
	conn=JdbcConnectivity.getConnection();
	try {
		st=conn.createStatement();
		
		br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the pin num that you want to Withdraw");
		int pno=Integer.parseInt(br.readLine());
		String s1="select pno from transactionhistory where pno="+pno;
		ResultSet rst=st.executeQuery(s1);
		
		if(rst.next()) {//if record exists
		System.out.println("enter amount that you want to withdarw");
		Float amount=Float.parseFloat(br.readLine());
		
		if(amount>0) {
		 availablebal=availablebal-amount;
		 System.out.println(availablebal);
	    String up1="update transactionhistory set withdraw="+amount+",availablebal="+availablebal+",transtype='"+transtype+"' where pno="+pno;
			int i=st.executeUpdate(up1);
			if(i>=0) {
				System.out.println("withdraw is successfull");
				System.out.println("Collect your cash");
				}
			else {
				System.out.println("transaction failed");
			}
			
			
		}
		
		}
		
		 }catch(Exception e) {
			 e.printStackTrace();
		 }

}

public static void deleteByPin() {
	conn=JdbcConnectivity.getConnection();
	try {
		st=conn.createStatement();
		
		br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the pin num that you want to Withdraw");
		int pno=Integer.parseInt(br.readLine());
		String s1="select pno from transactionhistory where pno="+pno;
		ResultSet rst=st.executeQuery(s1);
		if(rst.next()) {
			String del="delete from transactionhistory where pno="+pno;
			int j=st.executeUpdate(del);
			if(j>0) {
				System.out.println("deletion is successfull");
				
				}
			else {
				System.out.println("deletion failed");
			}
			
			
		}
		else {
			System.out.println(pno+"pno is not exist delete is not possible");
		}
		
		 }catch(Exception e) {
			 e.printStackTrace();
		 }
		}
	

public static void displayAllRecords() {
	
	conn=JdbcConnectivity.getConnection();
	try {
		 st=conn.createStatement();
		  String sell="select * from transactionhistory";
		  rs=st.executeQuery(sell);
		 
		  System.out.println("pno\tcname\ttranstype\twithdraw\tdeposit\tavailablebal");
		  while(rs.next()) {
			  int pno=rs.getInt(1); //or rs.getInt("id");
			  String cname=rs.getString(2);
			  String transtype=rs.getString(3);
			  float withdraw=rs.getFloat(4);
			  float deposit=rs.getFloat(5);
			  float availablebal=rs.getFloat(6);
	System.out.println(pno+"\t"+cname+"\t"+transtype+"\t"+withdraw+"\t"+deposit+"\t"+availablebal);
		  }
		  
		 }catch(Exception e) {
			 e.printStackTrace();
		 }
		
	}
}

	



	


	


