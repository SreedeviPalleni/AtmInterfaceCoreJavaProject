package newatminterface;

import java.io.IOException;

import java.util.Scanner;

public class MainClass {
  static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) throws IOException{
		while(true) {
		System.out.println("wELCOME TO SBI BANK");
		System.out.println("BEFORE TO PROCEED PLEASE SELECT THE BELOW OPTIONS");
		System.out.println("1.Add customer deatials");
		System.out.println("2.Deposit  Amount");
		System.out.println("3.Withdraw Amount:");
		System.out.println("4.Deletion:");
		System.out.println("5.Display records");
		System.out.println("6.Exit");
		System.out.println("SELECT YOUR CHOICE");
		int ch=sc.nextInt();
		switch(ch) {
		case 1:
			TransactionClass.addRecords();
			break;
		case 2:
			TransactionClass.depositAmount();
			break;
		case 3:
			TransactionClass.withdrawAmount();
			break;
		case 4:
			TransactionClass.deleteByPin();
			break;
		   case 5:
			TransactionClass.displayAllRecords();
			break;
		case 6:
			System.exit(0);
			
			
			
		}
		

	}
	}
}


